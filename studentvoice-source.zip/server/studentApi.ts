import crypto from "node:crypto";
import { promisify } from "node:util";
import type { Express, Request, Response } from "express";
import mysql from "mysql2/promise";

const scrypt = promisify(crypto.scrypt);
const SESSION_MAX_AGE = 1000 * 60 * 60 * 24 * 30;
const pool = process.env.DATABASE_URL ? mysql.createPool(process.env.DATABASE_URL) : null;

function cookieOptions(req: Request) {
  const forwarded = String(req.headers["x-forwarded-proto"] || "").split(",")[0].trim();
  const secure = req.secure || forwarded === "https" || process.env.NODE_ENV === "production";
  return { httpOnly: true, sameSite: secure ? ("none" as const) : ("lax" as const), secure, maxAge: SESSION_MAX_AGE, path: "/" };
}

function token() { return crypto.randomBytes(32).toString("base64url"); }
function digest(value: string) { return crypto.createHash("sha256").update(value).digest("hex"); }
function cleanHandle(value: unknown) { return String(value || "").trim(); }
function validHandle(value: string) { return /^[a-zA-Z0-9_-]{3,32}$/.test(value); }
function cookies(req: Request) {
  return Object.fromEntries(String(req.headers.cookie || "").split(";").map(part => part.trim().split("=")).filter(pair => pair.length === 2).map(([key, ...value]) => [key, decodeURIComponent(value.join("="))]));
}

async function hashPassword(password: string) {
  const salt = crypto.randomBytes(16).toString("hex");
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return `${salt}:${derived.toString("hex")}`;
}

async function verifyPassword(password: string, stored: string) {
  const [salt, expected] = stored.split(":");
  if (!salt || !expected) return false;
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  const expectedBuffer = Buffer.from(expected, "hex");
  return expectedBuffer.length === derived.length && crypto.timingSafeEqual(expectedBuffer, derived);
}

async function query<T = any>(sql: string, params: unknown[] = []) {
  if (!pool) throw new Error("DATABASE_URL is not configured");
  const [rows] = await pool.execute(sql, params);
  return rows as T;
}

export async function ensureStudentTables() {
  if (!pool) return;
  await query(`CREATE TABLE IF NOT EXISTS student_accounts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    handle VARCHAR(32) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  )`);
  await query(`CREATE TABLE IF NOT EXISTS student_sessions (
    token_hash CHAR(64) NOT NULL PRIMARY KEY,
    account_id BIGINT UNSIGNED NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_student_sessions_account (account_id),
    CONSTRAINT fk_student_sessions_account FOREIGN KEY (account_id) REFERENCES student_accounts(id) ON DELETE CASCADE
  )`);
  await query(`CREATE TABLE IF NOT EXISTS student_reports (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    reference_no VARCHAR(32) NOT NULL UNIQUE,
    account_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(180) NOT NULL,
    category VARCHAR(80) NOT NULL,
    district VARCHAR(80) NOT NULL,
    location VARCHAR(180) NULL,
    description TEXT NOT NULL,
    urgency VARCHAR(20) NOT NULL,
    status VARCHAR(40) NOT NULL DEFAULT 'Submitted',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_student_reports_account (account_id),
    CONSTRAINT fk_student_reports_account FOREIGN KEY (account_id) REFERENCES student_accounts(id) ON DELETE CASCADE
  )`);
  await query(`CREATE TABLE IF NOT EXISTS student_report_updates (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    report_id BIGINT UNSIGNED NOT NULL,
    status VARCHAR(40) NOT NULL,
    message TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_student_report_updates_report (report_id),
    CONSTRAINT fk_student_report_updates_report FOREIGN KEY (report_id) REFERENCES student_reports(id) ON DELETE CASCADE
  )`);
  await query(`CREATE TABLE IF NOT EXISTS agency_sessions (
    token_hash CHAR(64) NOT NULL PRIMARY KEY,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`);
}

async function studentAccount(req: Request) {
  const raw = cookies(req).student_session || req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (!raw) return null;
  const rows = await query<any[]>(`SELECT a.id, a.handle FROM student_sessions s JOIN student_accounts a ON a.id=s.account_id WHERE s.token_hash=? AND s.expires_at > NOW() LIMIT 1`, [digest(raw)]);
  return rows[0] || null;
}

async function agencyAuthorized(req: Request) {
  const raw = cookies(req).agency_session || req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (!raw) return false;
  const rows = await query<any[]>(`SELECT token_hash FROM agency_sessions WHERE token_hash=? AND expires_at > NOW() LIMIT 1`, [digest(raw)]);
  return rows.length > 0;
}

function requireBody(req: Request, res: Response, fields: string[]) {
  const missing = fields.find(field => !String(req.body?.[field] || "").trim());
  if (missing) { res.status(400).json({ error: `${missing} is required` }); return false; }
  return true;
}

export function registerStudentApi(app: Express) {
  app.post("/api/student/register", async (req, res) => {
    try {
      if (!requireBody(req, res, ["handle", "password"])) return;
      const handle = cleanHandle(req.body.handle);
      const password = String(req.body.password);
      if (!validHandle(handle)) return res.status(400).json({ error: "Handle must be 3–32 letters, numbers, hyphens or underscores" });
      if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters" });
      const passwordHash = await hashPassword(password);
      const result: any = await query(`INSERT INTO student_accounts (handle, password_hash) VALUES (?, ?)`, [handle, passwordHash]);
      const session = token();
      await query(`INSERT INTO student_sessions (token_hash, account_id, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))`, [digest(session), result.insertId]);
      res.cookie("student_session", session, cookieOptions(req)).json({ handle });
    } catch (error: any) {
      if (error?.code === "ER_DUP_ENTRY") return res.status(409).json({ error: "That anonymous handle is already in use" });
      console.error("student register", error); res.status(500).json({ error: "Account creation failed" });
    }
  });

  app.post("/api/student/login", async (req, res) => {
    try {
      if (!requireBody(req, res, ["handle", "password"])) return;
      const rows = await query<any[]>(`SELECT id, handle, password_hash FROM student_accounts WHERE handle=? LIMIT 1`, [cleanHandle(req.body.handle)]);
      if (!rows[0] || !(await verifyPassword(String(req.body.password), rows[0].password_hash))) return res.status(401).json({ error: "Invalid handle or password" });
      const session = token();
      await query(`INSERT INTO student_sessions (token_hash, account_id, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))`, [digest(session), rows[0].id]);
      res.cookie("student_session", session, cookieOptions(req)).json({ handle: rows[0].handle });
    } catch (error) { console.error("student login", error); res.status(500).json({ error: "Sign-in failed" }); }
  });

  app.post("/api/student/logout", async (req, res) => {
    try { const raw = cookies(req).student_session; if (raw) await query(`DELETE FROM student_sessions WHERE token_hash=?`, [digest(raw)]); } catch { /* session expiry is safe */ }
    res.clearCookie("student_session", cookieOptions(req)).json({ ok: true });
  });

  app.get("/api/student/me", async (req, res) => {
    try { const account = await studentAccount(req); if (!account) return res.status(401).json({ error: "Not signed in" }); res.json(account); }
    catch (error) { console.error("student me", error); res.status(500).json({ error: "Account lookup failed" }); }
  });

  app.get("/api/student/reports", async (req, res) => {
    try {
      const account = await studentAccount(req); if (!account) return res.status(401).json({ error: "Not signed in" });
      const reports = await query<any[]>(`SELECT r.id, r.reference_no AS ref, r.title, r.category, r.district, r.location, r.description, r.urgency, r.status, r.created_at AS date, u.message AS action FROM student_reports r LEFT JOIN student_report_updates u ON u.id=(SELECT MAX(id) FROM student_report_updates WHERE report_id=r.id) WHERE r.account_id=? ORDER BY r.created_at DESC`, [account.id]);
      res.json({ reports });
    } catch (error) { console.error("student reports", error); res.status(500).json({ error: "Reports unavailable" }); }
  });

  app.post("/api/student/reports", async (req, res) => {
    try {
      const account = await studentAccount(req); if (!account) return res.status(401).json({ error: "Not signed in" });
      if (!requireBody(req, res, ["title", "category", "district", "description", "urgency"])) return;
      const reference = `SV-${Date.now().toString(36).toUpperCase()}-${crypto.randomInt(100, 999)}`;
      const result: any = await query(`INSERT INTO student_reports (reference_no, account_id, title, category, district, location, description, urgency) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, [reference, account.id, String(req.body.title).trim(), String(req.body.category), String(req.body.district), String(req.body.location || "").trim() || null, String(req.body.description).trim(), String(req.body.urgency)]);
      await query(`INSERT INTO student_report_updates (report_id, status, message) VALUES (?, 'Submitted', 'Report received and queued for authorized review')`, [result.insertId]);
      res.status(201).json({ ref: reference });
    } catch (error) { console.error("student report", error); res.status(500).json({ error: "Report submission failed" }); }
  });

  app.post("/api/agency/login", async (req, res) => {
    const expected = process.env.AGENCY_ACCESS_CODE || "rimshaagency26";
    if (String(req.body?.accessCode || "") !== expected) return res.status(401).json({ error: "Invalid agency access code" });
    try {
      const session = token();
      await query(`INSERT INTO agency_sessions (token_hash, expires_at) VALUES (?, DATE_ADD(NOW(), INTERVAL 12 HOUR))`, [digest(session)]);
      res.cookie("agency_session", session, cookieOptions(req)).json({ ok: true });
    } catch (error) { console.error("agency login", error); res.status(500).json({ error: "Agency sign-in failed" }); }
  });

  app.get("/api/agency/reports", async (req, res) => {
    try {
      if (!(await agencyAuthorized(req))) return res.status(401).json({ error: "Agency authorization required" });
      const reports = await query<any[]>(`SELECT id, reference_no AS ref, title, category, district, location, description, urgency, status, created_at AS date FROM student_reports ORDER BY created_at DESC`);
      res.json({ reports });
    } catch (error) { console.error("agency reports", error); res.status(500).json({ error: "Agency reports unavailable" }); }
  });

  app.patch("/api/agency/reports/:id", async (req, res) => {
    try {
      if (!(await agencyAuthorized(req))) return res.status(401).json({ error: "Agency authorization required" });
      const id = Number(req.params.id); const status = String(req.body?.status || "").trim(); const message = String(req.body?.message || "").trim();
      if (!id || !status) return res.status(400).json({ error: "Status is required" });
      await query(`UPDATE student_reports SET status=? WHERE id=?`, [status, id]);
      await query(`INSERT INTO student_report_updates (report_id, status, message) VALUES (?, ?, ?)`, [id, status, message || null]);
      res.json({ ok: true });
    } catch (error) { console.error("agency update", error); res.status(500).json({ error: "Update failed" }); }
  });
}
